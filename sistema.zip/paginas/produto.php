<html>

<head>

    <title>Produto - Oscar Jóias e Acessórios</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet" href="lightslider/src/css/lightslider.css" />                  
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="lightslider/src/js/lightslider.js"></script>
    

    <?php

    /* Definindo a base para o site */
    include "php/base_paginas.php";
    
    ?>

    <link rel="stylesheet" href="css/produto.css">

    <script>

        $(document).ready(function() {
            $('#imageGallery').lightSlider({
                gallery:true,
                item:1,
                loop:true,
                thumbItem:7,
                slideMargin:0,
                enableDrag: true,
                adaptiveHeight:true,
                currentPagerPosition:'left',
                controls: false,
                onSliderLoad: function(el) {
                    el.lightGallery({
                        selector: '#imageGallery .lslide'
                    });
                }   
            });  
        });

        $(document).ready(function() {
            var slider = $('#aroFeminino').lightSlider({
                /* item:10, */
                slideMove:1,
                controls: false,
                pager: false,
                autoWidth:true,
                easing: 'cubic-bezier(0.25, 0, 0.25, 1)',

                speed: 200, //ms'
                auto: false,
                loop: false,
                slideEndAnimation: true,
                pause: 4000,
            });
            $('#botaoAntesFeminino').click(function(){
                slider.goToPrevSlide(); 
            });
            $('#botaoDepoisFeminino').click(function(){
                slider.goToNextSlide(); 
            });  
        });

        $(document).ready(function() {
            var slider = $('#aroMasculino').lightSlider({
                /* item:10, */
                slideMove:1,
                controls: false,
                pager: false,
                autoWidth:true,
                easing: 'cubic-bezier(0.25, 0, 0.25, 1)',

                speed: 200, //ms'
                auto: false,
                loop: false,
                slideEndAnimation: true,
                pause: 4000,
            });
            $('#botaoAntesMasculino').click(function(){
                slider.goToPrevSlide(); 
            });
            $('#botaoDepoisMasculino').click(function(){
                slider.goToNextSlide(); 
            });  
        });

        $(document).ready(function() {
            $('#espacoItem').lightSlider({
                item:5,
                slideMove:1,
                pager: false,
                controls:false,
                easing: 'cubic-bezier(0.25, 0, 0.25, 1)',

                speed: 700, //ms'
                auto: true,
                loop: true,
                slideEndAnimation: true,
                pause: 4000,
                responsive : [
                    {
                        breakpoint:980,
                        settings: {
                            item:4,
                            slideMove:1,
                        }
                    },

                    {
                        breakpoint:900,
                        settings: {
                            item:3,
                            slideMove:1,
                        }
                    },

                    {
                        breakpoint:550,
                        settings: {
                            item:2,
                            slideMove:1
                        }
                    },

                    {
                        breakpoint:400,
                        settings: {
                            item:1,
                            slideMove:1
                        }
                    }
                ]
            });  
        });

    </script>

</head>

<body>

    <div class="container-fluid">

        <?php
      
        /* Cabeçalho */
        include "phpPartes/cabecalho.php";
        
        ?>

        <div class="row justify-content-center">

            <div class="col-12 col-md-4 border-top pt-3">

                <ul id="imageGallery">
                    <li data-thumb="img/aneis/3.jpg" data-src="img/aneis/3.jpg">
                      <img id="imgSlide" src="img/aneis/3.jpg" width="100%"/>
                    </li>
                    <li data-thumb="img/aneis/5.jpg" data-src="img/aneis/5.jpg">
                      <img id="imgSlide" src="img/aneis/5.jpg" width="100%"/>
                    </li>
                    <li data-thumb="img/aneis/1.jpg" data-src="img/aneis/1.jpg">
                        <img id="imgSlide" src="img/aneis/1.jpg" width="100%"/>
                    </li>
                    <li data-thumb="img/aneis/4.jpg" data-src="img/aneis/4.jpg">
                    <img id="imgSlide" src="img/aneis/4.jpg" width="100%"/>
                    </li>
                    <li data-thumb="img/aneis/2.jpg" data-src="img/aneis/2.jpg">
                    <img id="imgSlide" src="img/aneis/2.jpg" width="100%"/>
                    </li>
                </ul>

            </div>

            <div class="col-12 col-md-5 border-top pt-3">

                <h1 class="fs-2 fw-light text-secondary">Aliança de Casamento Ouro Amarelo ao ouro (2mm)</h1>

                <div class="row mt-3">

                    <div class="col-4">

                        <select class="mt-2 text-secondary" id="selectQtd">

                            <option>Quantidade: 1</option>
                            <option>Quantidade: 2</option>
                            <option>Quantidade: 3</option>
                            <option>Quantidade: 4</option>
                            <option>Quantidade: 5</option>

                        </select>

                    </div>

                    <div class="col-8 text-end">

                        <span class="fs-2 text-secondary">R$1458,90</span>

                    </div>

                </div>

                <!-- Box Feminio -->
                <div class="row justify-content-center mt-4">

                    <div id="boxAro" class="col-11">

                        <div class="row mt-2">

                            <div class="col">

                                <span class="text-secondary">Tamanho do aro feminino</span>

                            </div>

                        </div>

                        <div class="row mt-2">

                            <div id="botaoAntesFeminino" class="col-1 fs-3"><</div>

                            <div class="col-10">

                                <ul class="col-12 col-md-9" id="aroFeminino">

                                    <?php
                            
                                    $i_aros = 9;

                                    while($i_aros <= 33){
                                    
                                    ?>

                                    <li class="text-center" id="espacoProdutoMaisVendidos">

                                        <div id="fundoNumero">

                                            <span id="numeroAro"><?php echo $i_aros; ?></span>
        
                                        </div>
                      
                                    </li>

                                    <?php

                                    $i_aros++;
                                    
                                    }
                                    
                                    ?>

                                </ul>

                            </div>

                            <div id="botaoDepoisFeminino" class="col-1 fs-3">></div>

                        </div>

                        <div class="row mt-3 mb-3">

                            <div class="col text-center text-secondary">

                                Gravação: <input class="text-secondary" id="campoGravacao" type="text">

                            </div>

                        </div>

                    </div>

                </div>
                <!-- //Box Feminio -->

                <!-- Box masculino -->
                <div class="row justify-content-center mt-4">

                    <div id="boxAro" class="col-11">

                        <div class="row mt-2">

                            <div class="col">

                                <span class="text-secondary">Tamanho do aro masculino</span>

                            </div>

                        </div>

                        <div class="row mt-2">

                            <div id="botaoAntesMasculino" class="col-1 fs-3"><</div>

                            <div class="col-10">

                                <ul class="col-12 col-md-9" id="aroMasculino">

                                    <?php
                            
                                    $i_aros = 9;

                                    while($i_aros <= 33){
                                    
                                    ?>

                                    <li class="text-center" id="espacoProdutoMaisVendidos">

                                        <div id="fundoNumero">

                                            <span id="numeroAro"><?php echo $i_aros; ?></span>
        
                                        </div>
                      
                                    </li>

                                    <?php

                                    $i_aros++;
                                    
                                    }
                                    
                                    ?>

                                </ul>

                            </div>

                            <div id="botaoDepoisMasculino" class="col-1 fs-3">></div>

                        </div>

                        <div class="row mt-3 mb-3">

                            <div class="col text-center text-secondary">

                                Gravação: <input class="text-secondary" id="campoGravacao" type="text">

                            </div>

                        </div>

                    </div>

                </div>
                <!-- //Box masculino -->

                <!-- Calculo do frete -->
                <div class="row justify-content-center mt-4 pt-3">

                    <div class="col-10">

                        <label class="text-secondary" for="inputCalculaFrete">Digite seu CEP para calcular o frete</label><br>
                        <input type="text" id="inputCalculaFrete">

                    </div>

                </div>
                <!-- //Calculo do frete -->

                <!-- Botao Add a sacola -->
                <div class="row justify-content-center mt-4 pt-4 pb-4">

                    <div class="col-10">

                        <button id="botaoAddCarrinho">ADICIONAR À SACOLA</button>

                    </div>

                </div>
                <!-- //Botao Add a sacola -->

            </div>

        </div>

        <!-- Caracteristicas -->
        <div class="row justify-content-center">

            <div class="col-md-9 border-top pt-4">

                <h2 class="fs-2 fw-light text-secondary">Características gerais</h2>

                <p class="text-secondary fw-light">

                    Ao contrário da crença popular, o Lorem Ipsum não é simplesmente texto aleatório. Tem raízes numa peça de literatura clássica em Latim, de 45 AC, tornando-o com mais de 2000 anos. Richard McClintock, um professor de Latim no Colégio Hampden-Sydney, na Virgínia, procurou uma das palavras em Latim mais obscuras (consectetur) numa passagem Lorem Ipsum, e atravessando as cidades do mundo na literatura clássica, descobriu a sua origem. Lorem Ipsum vem das secções 1.10.32 e 1.10.33 do "de Finibus Bonorum et Malorum" (Os Extremos do Bem e do Mal), por Cícero, escrito a 45AC. Este livro é um tratado na teoria da ética, muito popular durante a Renascença. A primeira linha de Lorem Ipsum, "Lorem ipsum dolor sit amet..." aparece de uma linha na secção 1.10.32.

                    O pedaço mais habitual do Lorem Ipsum usado desde os anos 1500 é reproduzido abaixo para os interessados. As secções 1.10.32 e 1.10.33 do "de Finibus Bonorum et Malorum" do Cícero também estão reproduzidos na sua forma original, acompanhados pela sua tradução em Inglês, versões da tradução de 1914 por H. Rackham.

                </p>

            </div>

        </div>
        <!-- //Caracteristicas -->

        <div class="row mt-5 justify-content-center">

            <div class="col-md-9 pt-3 border-top">
  
                <p class="pb-2"><span class="text-secondary fs-4">Você pode se interessar</span></p>
  
            </div>
  
        </div>

        <div class="row justify-content-center">

            <div class="col-12 col-md-9">
    
              <ul class="col-12 col-md-9" id="espacoItem">
    
                <li class="text-center" id="espacoProdutoMaisVendidos">
    
                      <div class="box">
    
                        <img src="img/aneis/5.jpg" id="fotoAnel">
    
                        <p class="card-text mt-1 pt-2 border-top">Anel porta objetos 400g</p>
    
                        <h5 class="card-title">R$500,00</h5>
    
                      </div>
    
                </li>
    
                <li class="text-center" id="espacoProdutoMaisVendidos">
    
                  <div class="box">
    
                    <img src="img/aneis/2.jpg" id="fotoAnel">
    
                    <p class="card-text mt-1 pt-2 border-top">Anel porta objetos 400g Anel porta objetos 400g</p>
    
                    <small class="text-decoration-line-through">R$500,00</small>
                    <h5 class="card-title">R$500,00</h5>
    
                  </div>
    
                </li>
    
                <li class="text-center" id="espacoProdutoMaisVendidos">
    
                  <div class="box">
    
                    <img src="img/aneis/3.jpg" id="fotoAnel">
    
                    <p class="card-text mt-1 pt-2 border-top">Anel porta objetos 400g</p>
    
                    <h5 class="card-title">R$500,00</h5>
    
                  </div>
    
                </li>
    
                <li class="text-center" id="espacoProdutoMaisVendidos">
    
                  <div class="box">
    
                    <img src="img/aneis/4.jpg" id="fotoAnel">
    
                    <p class="card-text mt-1 pt-2 border-top">Anel porta objetos 400g</p>
    
                    <h5 class="card-title">R$500,00</h5>
    
                  </div>
    
                </li>
    
                <li class="text-center" id="espacoProdutoMaisVendidos">
    
                  <div class="box">
    
                    <img src="img/aneis/1.jpg" id="fotoAnel">
    
                    <p class="card-text mt-1 pt-2 border-top">Anel porta objetos 400g</p>
    
                    <h5 class="card-title">R$500,00</h5>
    
                  </div>
    
                </li>
    
                <li class="text-center" id="espacoProdutoMaisVendidos">
    
                  <div class="box">
    
                    <img src="img/aneis/2.jpg" id="fotoAnel">
    
                    <p class="card-text mt-1 pt-2 border-top">Anel porta objetos 400g</p>
    
                    <h5 class="card-title">R$500,00</h5>
    
                  </div>
    
                </li>
    
                <li class="text-center" id="espacoProdutoMaisVendidos">
    
                  <div class="box">
    
                    <img src="img/aneis/3.jpg" id="fotoAnel">
    
                    <p class="card-text mt-1 pt-2 border-top">Anel porta objetos 400g</p>
    
                    <h5 class="card-title">R$500,00</h5>
    
                  </div>
    
                </li>
    
                <li class="text-center" id="espacoProdutoMaisVendidos">
    
                  <div class="box">
    
                    <img src="img/aneis/4.jpg" id="fotoAnel">
    
                    <p class="card-text mt-1 pt-2 border-top">Anel porta objetos 400g</p>
    
                    <h5 class="card-title">R$500,00</h5>
    
                  </div>
    
                </li>
    
                <li class="text-center" id="espacoProdutoMaisVendidos">
    
                  <div class="box">
    
                    <img src="img/aneis/1.jpg" id="fotoAnel">
    
                    <p class="card-text mt-1 pt-2 border-top">Anel porta objetos 400g</p>
    
                    <h5 class="card-title">R$500,00</h5>
    
                  </div>
    
                </li>
    
                <li class="text-center" id="espacoProdutoMaisVendidos">
    
                  <div class="box">
    
                    <img src="img/aneis/2.jpg" id="fotoAnel">
    
                    <p class="card-text mt-1 pt-2 border-top">Anel porta objetos 400g</p>
    
                    <h5 class="card-title">R$500,00</h5>
    
                  </div>
    
                </li>
    
              </ul>
    
            </div>
    
        </div>

        <?php
      
        /* Rodapé */
        include "phpPartes/rodape.php";
        
        ?>

    </div>
    
</body>

</html>