<link rel="stylesheet" href="cssPartes/rodape.css">

<!-- Rodapé -->
<div class="row justify-content-center mt-5" id="fundoFooter">

    <div class="col-12 col-md-9">

      <footer>

        Desenvolvido por Erick Mota

      </footer>

    </div>

</div>
<!-- //Rodapé -->