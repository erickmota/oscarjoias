<link rel="stylesheet" href="cssPartes/cabecalho.css">

<div class="row">

    <div class="col bg-danger text-white text-center">

        *Esse site está em desenvolvimento!

    </div>

</div>

<!-- Topo site: Logo, Busca etc -->
<div class="row mt-2 justify-content-center">

    <div class="col-6 col-md-4 border-bottom">

        <img src="img/logo.png" id="imgLogo" width="130px">

    </div>

    <div class="col-6 col-md-5 border-bottom pb-3">

        <div class="row">

            <div class="col-2">

                <img id="iconePessoa" src="img/iconePessoa2.png" width="26px">

            </div>

            <div class="col-2">

                <img id="iconeSacola" src="img/iconeBolsa2.png" width="21px">

            </div>

            <div class="col-8">

                <form>

                    <input type="text" id="campoBusca" placeholder="Buscar Produto">

                </form>

            </div>

        </div>

    </div>

</div>
<!-- //Topo site: Logo, Busca etc -->

<!-- Menu principal -->
<div class="row justify-content-center">

    <div class="col-md-9 text-center">

        <nav id="menu">
            <ul>
                <li><a href="">Início</a></li>

                <li><a href="loja">Loja</a></li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Categorias
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDarkDropdownMenuLink">
                        <li><a class="dropdown-item" href="#">Aneis</a></li>
                        <li><a class="dropdown-item" href="#">Alianças</a></li>
                        <li><a class="dropdown-item" href="#">Correntes</a></li>
                        <li><a class="dropdown-item" href="#">Ouro</a></li>
                        <li><a class="dropdown-item" href="#">Prata</a></li>
                    </ul>
                </li>

                <li><a href="#">Quem Somos</a></li>

                <li><a href="#">Contato</a></li>
            </ul>
        </nav>

    </div>

</div>
<!-- //Menu principal -->