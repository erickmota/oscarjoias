<base href='http://localhost/OscarJoias/sistema/'>
<!-- <base href='http://lojaoscar.erickmota.com/'> -->