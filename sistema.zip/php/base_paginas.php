<base href='http://localhost/OscarJoias/sistema/'>
<!-- <base href='https://lojaoscar.erickmota.com/'> -->