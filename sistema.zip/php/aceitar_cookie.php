<?php

setcookie("cookies_oscar_joias", "aceitos", time() + 7 * (24 * 3600), "/");

?>